import pytest

"""
Example test to show how to add a test for anything in the project.  
Look at the README for more instructions   
"""


def test_cube():
    assert 27 == 27

if __name__ == '__main__':
    pytest.main([__file__])
